# 📝 토플 라이팅 자동 채점기 (TOEFL AI Scorer)

## 📌 프로젝트 개요 (Project Overview)
이 프로젝트는 웹 기반의 자동 에세이 채점 애플리케이션입니다.
Assignment 5에서 학습시킨 **DeBERTa-v3-small** 파인튜닝 모델을 사용하여 토플 라이팅 점수(0~30점)를 예측합니다.

## ⚙️ 실행 방법 (How to Run)
1. 필수 라이브러리 설치:
   `pip install -r requirements.txt`
2. 앱 실행:
   `streamlit run app.py`

## 🏗️ 모델 상세 (Model Details)
- **아키텍처:** Microsoft DeBERTa-v3-small
- **보정(Calibration):** 학습 데이터 부족으로 인한 편향을 해결하기 위해, 모델의 원시 출력값(Raw Output)에 선형 스케일링(x3.5)을 적용하여 실제 토플 점수 분포에 맞췄습니다.