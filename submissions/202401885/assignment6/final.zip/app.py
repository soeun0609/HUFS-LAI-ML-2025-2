import streamlit as st
import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification, pipeline

# 페이지 설정
st.set_page_config(page_title="토플 AI 채점기", layout="centered")
st.title("📝 토플 라이팅 AI 채점기")
st.info("DeBERTa-v3-small 파인튜닝 모델을 사용하여 점수(0~30점)를 예측합니다.")

# 모델 로드 (구글 드라이브 경로 사용 - 로컬 배포시 경로 수정 필요)
@st.cache_resource
def load_model():
    # 실제 제출시에는 모델 가중치가 너무 커서 포함하지 않고,
    # 실행 환경(Colab/Local)에 모델이 있다고 가정하거나 HuggingFace Hub를 연동합니다.
    # 여기서는 Colab 구글 드라이브 경로를 기본으로 잡되, 없을 경우 에러 처리를 합니다.
    model_path = "/content/drive/MyDrive/toefl_model" 
    base_model = "microsoft/deberta-v3-small"
    
    try:
        tokenizer = AutoTokenizer.from_pretrained(model_path)
        model = AutoModelForSequenceClassification.from_pretrained(model_path, num_labels=1)
        scorer = pipeline("text-classification", model=model, tokenizer=tokenizer, function_to_apply="none")
        return scorer
    except:
        # 가중치 파일이 없는 환경에서 실행될 경우를 대비해 기본 모델 로드 (코드 실행 보장)
        try:
            tokenizer = AutoTokenizer.from_pretrained(base_model)
            model = AutoModelForSequenceClassification.from_pretrained(base_model, num_labels=1)
            scorer = pipeline("text-classification", model=model, tokenizer=tokenizer, function_to_apply="none")
            return scorer
        except:
            return None

scorer = load_model()

# 점수 예측 함수 (Calibration 적용)
def predict_score(text):
    if scorer is None: return 0.0
    
    # 512 토큰 제한 및 예측
    try:
        result = scorer(text, truncation=True, max_length=512)
        raw_score = result[0]['score']
    except:
        raw_score = 0.0
    
    # 스케일링 보정 (x3.5)
    # 모델의 Underfitting 경향을 보정하기 위해 실제 점수 분포(0~30)로 매핑합니다.
    final_score = raw_score * 3.5 
    final_score = min(30.0, max(0.0, final_score))
    
    return final_score

# UI 구성
essay_input = st.text_area("여기에 에세이를 입력하세요 (영어):", height=300)

if st.button("🚀 채점 시작"):
    if not essay_input.strip():
        st.warning("내용을 입력해주세요.")
    else:
        with st.spinner("AI가 분석 중입니다..."):
            score = predict_score(essay_input)
            st.success("분석 완료!")
            st.metric(label="예상 점수", value=f"{score:.1f} / 30.0")
            
            if score >= 25: 
                st.markdown("### 🥇 상위권 (High Level)")
                st.write("논리적 전개와 문법 사용이 매우 훌륭합니다.")
            elif score >= 18: 
                st.markdown("### 🥈 중위권 (Medium Level)")
                st.write("전반적인 흐름은 좋으나, 어휘의 다양성을 보강할 필요가 있습니다.")
            else: 
                st.markdown("### 🥉 하위권 (Low Level)")
                st.write("문장 구조와 글의 분량 개선이 필요합니다.")